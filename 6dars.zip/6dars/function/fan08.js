function AddLeftDigit(a, b) {
  return a * 10 + b;
}

console.log(AddLeftDigit(45, 7));
