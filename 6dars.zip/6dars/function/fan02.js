function PowerA234(a, b, c) {
  console.log(Math.pow(a, 2), Math.pow(b, 3), Math.pow(c, 4));
}

PowerA234(2, 2, 2);
