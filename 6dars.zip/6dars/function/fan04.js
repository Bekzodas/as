function Triangle(a) {
  console.log(a * 3);
  console.log(Math.sqrt(3) / 4) * Math.pow(a, 2);
}

Triangle(4);
