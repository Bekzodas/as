function PowerA3(a) {
  return a * a * a;
}
console.log(PowerA3(1));
console.log(PowerA3(2));
console.log(PowerA3(3));
console.log(PowerA3(4));
console.log(PowerA3(5));
