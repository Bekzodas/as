function MEAN(a, b) {
  let arif = (a + b) / 2;
  console.log("o'rta geometrik: ", Math.sqrt(a * b), "Arofmetik", arif);
}

MEAN(12, 24);
