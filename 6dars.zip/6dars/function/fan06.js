function DigitCountSum(a, b, c) {
  let sum;
  sum = a + b + c;
  return sum;
}

console.log(DigitCountSum(4, 4, 4));
