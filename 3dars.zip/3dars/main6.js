let a = 2;
let b = 7;
if (a > b) {
  console.log(a);
} else {
  console.log(b);
}
