let a = 5;
let b = 7;
let c = -4;

let musbat = 0;
if (a > 0) {
  musbat++;
}
if (b > 0) {
  musbat++;
}
if (c > 0) {
  musbat++;
}
console.log(musbat);
