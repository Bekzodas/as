let one = 15;
let two = 54;
let three = 15;
let fore = 15;
if ((one == two) == three) {
  console.log(4);
} else if ((one == two) == fore) {
  console.log(3);
} else if ((one == three) == fore) {
  console.log(2);
} else {
  console.log(1);
}
