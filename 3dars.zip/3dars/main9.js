let a = 10;
let b = 5;
let c;
if (a > b) {
  c = a;
  a = b;
  b = c;
}
console.log(a, b);
