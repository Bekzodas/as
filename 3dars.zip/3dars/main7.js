let a = 10;
let b = 5;

if (a < b) {
  console.log(1);
} else {
  console.log(2);
}
