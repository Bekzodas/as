let a = 10;
let b = 5;
if (a > b) {
  console.log(a, b);
} else {
  console.log(b, a);
}
