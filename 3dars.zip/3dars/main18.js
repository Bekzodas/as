let one = 15;
let two = 54;
let three = 15;
if (one == two) {
  console.log(3);
} else if (one == three) {
  console.log(2);
} else {
  console.log(1);
}
