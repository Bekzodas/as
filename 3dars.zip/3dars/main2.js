let a = 5;
if (a > 0) {
  a++;
} else {
  a -= 2;
}
console.log(a);
