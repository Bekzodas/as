let a = 10;
let b = 5;
let c = 8;
let min = a;
if (min > b) {
  min = b;
}
if (min > c) {
  min = c;
} else {
  console.log(min);
}
console.log(min);
