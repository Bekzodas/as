let a = 5;
if (a > 0) {
  a++;
} else if (a < 0) {
  a -= 2;
} else if (a == 0) {
  a = 10;
}
console.log(a);
