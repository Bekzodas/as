let a = 10;
let b = 20;
let c = -10;

let mus = 0;
let man = 0;

if (a > 0) mus++;
else man++;
if (b > 0) mus++;
else man++;
if (c > 0) mus++;
else man++;
console.log(mus, man);
