let a = 7;
if (a > 0) a++;
console.log(a);
